package com.assignment1;

public class DLNode<T>{
    public T data;
    public DLNode next, prev;
}
