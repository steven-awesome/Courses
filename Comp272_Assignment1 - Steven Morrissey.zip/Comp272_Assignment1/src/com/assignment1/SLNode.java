package com.assignment1;

public class SLNode<T>{
    public T x;
    public SLNode<T> next;
}
